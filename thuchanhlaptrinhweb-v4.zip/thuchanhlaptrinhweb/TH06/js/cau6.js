function luu() {
    
    var hoten = document.getElementById("hoten");
    var vtlv = document.getElementById("vtlv");
    var luong = document.getElementById("luong");
    var gioitinhnam = document.getElementById("gioitinhnam");
    var gioitinhnu = document.getElementById("gioitinhnu");
    
    
    if (hoten.value.trim() == "") {
        alert("Họ và tên không được để trống !");
        hoten.focus();
    } else if (hoten.value.trim().length < 8) {
        alert("Họ và tên không nhập ít hơn 8 ký tự");
        hoten.focus();
    } else if (vtlv.value.trim() == "") {
        alert("Vị trí làm việc không được để trống");
        vtlv.focus();
    } else if (vtlv.value.length > 100) {
        alert("Vị trí làm việc không được nhập quá 100 ký tự");
        vtlv.focus();
    } else if (luong.value < 0 || luong.value == "") {
        alert("Lương không để số âm hoặc rỗng");
        luong.focus();
    } else if (gioitinhnam.checked == false && gioitinhnu.checked == false) {
        alert("Vui lòng chọn giới tính");
    } else {
        
        var showDiv = document.getElementsByClassName("show")[0];
        
        
        showDiv.style.display = 'block';
        
        
        document.getElementById("hotenx").innerHTML = hoten.value;
        document.getElementById("vtlvx").innerHTML = vtlv.value;
        document.getElementById("luongx").innerHTML = luong.value;
        
        if (gioitinhnam.checked) {
            document.getElementById("gioitinhx").innerHTML = gioitinhnam.value;
        } else {
            document.getElementById("gioitinhx").innerHTML = gioitinhnu.value;
        }

        
        document.getElementsByClassName("container")[0].style.backgroundColor = "#dff0d8";
    }
}