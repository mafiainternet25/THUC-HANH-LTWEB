function showTime() {
    var date = new Date(); // Lấy ngày tháng hiện tại
    var h = date.getHours(); // Giờ 0 - 23
    var m = date.getMinutes(); // Phút 0 - 59
    var s = date.getSeconds(); // Giây 0 - 59
    var session = "AM";

    if (h == 0) {
        h = 12;
    }

    if (h > 12) {
        h = h - 12;
        session = "PM";
    }

    // Thêm số 0 vào trước nếu nhỏ hơn 10 (ví dụ: 09)
    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;

    var time = h + ":" + m + ":" + s + " " + session;
    
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;

    setTimeout(showTime, 1000); // Cập nhật mỗi 1000ms (1 giây)
}

showTime();