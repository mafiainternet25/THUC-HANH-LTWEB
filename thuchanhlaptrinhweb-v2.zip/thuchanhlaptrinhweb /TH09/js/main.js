function myFunction() {
    var x = document.getElementById("myMidnav");
    if (x.className === "mid-nav") {
        x.className += " responsive";
    } else {
        x.className = "mid-nav";
    }
}